# 🫧 Deploy to Netlify

## Just upload this ONE file:

**index.html** 

That's it!

## Steps:

1. Download `index.html`
2. Go to https://app.netlify.com/drop
3. Drag `index.html` onto the page
4. Get your URL instantly!

Your app will work immediately on the URL Netlify gives you.

## Then Add to Home Screen:

**iPhone:**
- Open in Safari
- Tap Share button
- "Add to Home Screen"

**Android:**
- Open in Chrome
- Tap menu (3 dots)
- "Add to Home screen"

✨ Enjoy your magical bubble to-do list!
